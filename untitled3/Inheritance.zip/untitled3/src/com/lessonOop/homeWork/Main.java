package com.lessonOop.homeWork;

import java.util.Scanner;

public class Main {

    static int index = 0;

    public static void main(String[] args) {
        User user1 = new User(1, "user1", "user1", "name1", "suername1");
        User user2 = new User(2, "user2", "user2", "name2", "suername2");
        User user3 = new User(3, "user3", "user3", "name3", "suername3");
        User user4 = new User(4, "user4", "user4", "name4", "suername4");
        User user5 = new User(5, "user5", "user5", "name5", "suername5");
        Staff staff1 = new Staff(6, "staff6", "staff6", "name6", "suername6", 1);
        Staff staff2 = new Staff(7, "staff7", "staff7", "name7", "suername7", 2);
        Staff staff3 = new Staff(8, "staff8", "staff8", "name8", "suername8", 3);
        Staff staff4 = new Staff(9, "staff9", "staff9", "name9", "suername9", 4);
        Staff staff5 = new Staff(10, "staff10", "staff10", "name10", "suername10", 3.4);
        Student student1 = new Student(11, "student11", "student11", "name11", "suername11", 1);
        Student student2 = new Student(12, "student12", "student12", "name12", "suername12", 2);
        Student student3 = new Student(13, "student13", "student13", "name13", "suername13", 3);
        Student student4 = new Student(14, "student14", "student14", "name14", "suername14", 4);
        Student student5 = new Student(15, "student15", "student15", "name15", "suername15", 2.3);
        User[] users = {user1, user2, user3, user4, user5, staff1, staff2, staff3, staff4, staff5, student1, student2, student3, student4, student5};
        staff1.addSubject("Math");
        staff1.addSubject("Physics");
        student1.addCourse("Math");
        student1.addCourse("Physics");
        for (User u: users) {
            if (u instanceof Staff && u.equals(staff1)){
                ((Staff) u).getSubjects();
                ((Staff) u).getData();
            }
        }
    }
}
